﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpaceStationScramble {
    class Cheater {
        public const bool CheatsOn = false;
    }
}
